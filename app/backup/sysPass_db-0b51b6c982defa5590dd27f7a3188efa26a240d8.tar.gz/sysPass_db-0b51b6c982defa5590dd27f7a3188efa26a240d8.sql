-- 
-- sysPass DB dump generated on 1603896115 (START)
-- 
-- Please, do not alter this file, it could break your DB
-- 
SET AUTOCOMMIT = 0;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
-- 
CREATE DATABASE IF NOT EXISTS `sysPass1`;

USE `sysPass1`;

-- 
-- Table CLIENT
-- 
DROP TABLE IF EXISTS `Client`;

CREATE TABLE `client` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `hash` varbinary(40) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isGlobal` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uk_Client_01` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table CATEGORY
-- 
DROP TABLE IF EXISTS `Category`;

CREATE TABLE `category` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hash` varbinary(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_Category_01` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table TAG
-- 
DROP TABLE IF EXISTS `Tag`;

CREATE TABLE `tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `hash` varbinary(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_Tag_01` (`hash`),
  KEY `idx_Tag_01` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table USERGROUP
-- 
DROP TABLE IF EXISTS `UserGroup`;

CREATE TABLE `usergroup` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table USERPROFILE
-- 
DROP TABLE IF EXISTS `UserProfile`;

CREATE TABLE `userprofile` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `profile` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table USER
-- 
DROP TABLE IF EXISTS `User`;

CREATE TABLE `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `userGroupId` smallint(5) unsigned NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ssoLogin` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varbinary(500) NOT NULL,
  `mPass` varbinary(2000) DEFAULT NULL,
  `mKey` varbinary(2000) DEFAULT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `loginCount` int(10) unsigned NOT NULL DEFAULT '0',
  `userProfileId` smallint(5) unsigned NOT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastUpdate` datetime DEFAULT NULL,
  `lastUpdateMPass` int(11) unsigned NOT NULL DEFAULT '0',
  `isAdminApp` tinyint(1) DEFAULT '0',
  `isAdminAcc` tinyint(1) DEFAULT '0',
  `isLdap` tinyint(1) DEFAULT '0',
  `isDisabled` tinyint(1) DEFAULT '0',
  `hashSalt` varbinary(255) NOT NULL,
  `isMigrate` tinyint(1) DEFAULT '0',
  `isChangePass` tinyint(1) DEFAULT '0',
  `isChangedPass` tinyint(1) DEFAULT '0',
  `preferences` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_User_01` (`login`,`ssoLogin`),
  KEY `idx_User_01` (`pass`),
  KEY `fk_User_userGroupId` (`userGroupId`),
  KEY `fk_User_userProfileId` (`userProfileId`),
  CONSTRAINT `fk_User_userGroupId` FOREIGN KEY (`userGroupId`) REFERENCES `usergroup` (`id`),
  CONSTRAINT `fk_User_userProfileId` FOREIGN KEY (`userProfileId`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNT
-- 
DROP TABLE IF EXISTS `Account`;

CREATE TABLE `account` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `userGroupId` smallint(5) unsigned NOT NULL,
  `userId` smallint(5) unsigned NOT NULL,
  `userEditId` smallint(5) unsigned NOT NULL,
  `clientId` mediumint(8) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `categoryId` mediumint(8) unsigned NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varbinary(2000) NOT NULL,
  `key` varbinary(2000) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `countView` int(10) unsigned NOT NULL DEFAULT '0',
  `countDecrypt` int(10) unsigned NOT NULL DEFAULT '0',
  `dateAdd` datetime NOT NULL,
  `dateEdit` datetime DEFAULT NULL,
  `otherUserGroupEdit` tinyint(1) DEFAULT '0',
  `otherUserEdit` tinyint(1) DEFAULT '0',
  `isPrivate` tinyint(1) DEFAULT '0',
  `isPrivateGroup` tinyint(1) DEFAULT '0',
  `passDate` int(11) unsigned DEFAULT NULL,
  `passDateChange` int(11) unsigned DEFAULT NULL,
  `parentId` mediumint(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_Account_01` (`categoryId`),
  KEY `idx_Account_02` (`userGroupId`,`userId`),
  KEY `idx_Account_03` (`clientId`),
  KEY `idx_Account_04` (`parentId`),
  KEY `fk_Account_userId` (`userId`),
  KEY `fk_Account_userEditId` (`userEditId`),
  CONSTRAINT `fk_Account_categoryId` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_Account_clientId` FOREIGN KEY (`clientId`) REFERENCES `client` (`id`),
  CONSTRAINT `fk_Account_userEditId` FOREIGN KEY (`userEditId`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_Account_userGroupId` FOREIGN KEY (`userGroupId`) REFERENCES `usergroup` (`id`),
  CONSTRAINT `fk_Account_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTTOFAVORITE
-- 
DROP TABLE IF EXISTS `AccountToFavorite`;

CREATE TABLE `accounttofavorite` (
  `accountId` mediumint(8) unsigned NOT NULL,
  `userId` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`accountId`,`userId`),
  KEY `idx_AccountToFavorite_01` (`accountId`,`userId`),
  KEY `fk_AccountToFavorite_userId` (`userId`),
  CONSTRAINT `fk_AccountToFavorite_accountId` FOREIGN KEY (`accountId`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_AccountToFavorite_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTFILE
-- 
DROP TABLE IF EXISTS `AccountFile`;

CREATE TABLE `accountfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` mediumint(5) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `content` mediumblob NOT NULL,
  `extension` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `thumb` mediumblob,
  PRIMARY KEY (`id`),
  KEY `idx_AccountFile_01` (`accountId`),
  CONSTRAINT `fk_AccountFile_accountId` FOREIGN KEY (`accountId`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTTOUSERGROUP
-- 
DROP TABLE IF EXISTS `AccountToUserGroup`;

CREATE TABLE `accounttousergroup` (
  `accountId` mediumint(8) unsigned NOT NULL,
  `userGroupId` smallint(5) unsigned NOT NULL,
  `isEdit` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`accountId`,`userGroupId`),
  KEY `idx_AccountToUserGroup_01` (`accountId`),
  KEY `fk_AccountToUserGroup_userGroupId` (`userGroupId`),
  CONSTRAINT `fk_AccountToUserGroup_accountId` FOREIGN KEY (`accountId`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_AccountToUserGroup_userGroupId` FOREIGN KEY (`userGroupId`) REFERENCES `usergroup` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTHISTORY
-- 
DROP TABLE IF EXISTS `AccountHistory`;

CREATE TABLE `accounthistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` mediumint(8) unsigned NOT NULL,
  `userGroupId` smallint(5) unsigned NOT NULL,
  `userId` smallint(5) unsigned NOT NULL,
  `userEditId` smallint(5) unsigned NOT NULL,
  `clientId` mediumint(8) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categoryId` mediumint(8) unsigned NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varbinary(2000) NOT NULL,
  `key` varbinary(2000) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `countView` int(10) unsigned NOT NULL DEFAULT '0',
  `countDecrypt` int(10) unsigned NOT NULL DEFAULT '0',
  `dateAdd` datetime NOT NULL,
  `dateEdit` datetime DEFAULT NULL,
  `isModify` tinyint(1) DEFAULT '0',
  `isDeleted` tinyint(1) DEFAULT '0',
  `mPassHash` varbinary(255) NOT NULL,
  `otherUserEdit` tinyint(1) DEFAULT '0',
  `otherUserGroupEdit` tinyint(1) DEFAULT '0',
  `passDate` int(10) unsigned DEFAULT NULL,
  `passDateChange` int(10) unsigned DEFAULT NULL,
  `parentId` mediumint(8) unsigned DEFAULT NULL,
  `isPrivate` tinyint(1) DEFAULT '0',
  `isPrivateGroup` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_AccountHistory_01` (`accountId`),
  KEY `idx_AccountHistory_02` (`parentId`),
  KEY `fk_AccountHistory_userGroupId` (`userGroupId`),
  KEY `fk_AccountHistory_userId` (`userId`),
  KEY `fk_AccountHistory_userEditId` (`userEditId`),
  KEY `fk_AccountHistory_clientId` (`clientId`),
  KEY `fk_AccountHistory_categoryId` (`categoryId`),
  CONSTRAINT `fk_AccountHistory_categoryId` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_AccountHistory_clientId` FOREIGN KEY (`clientId`) REFERENCES `client` (`id`),
  CONSTRAINT `fk_AccountHistory_userEditId` FOREIGN KEY (`userEditId`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_AccountHistory_userGroupId` FOREIGN KEY (`userGroupId`) REFERENCES `usergroup` (`id`),
  CONSTRAINT `fk_AccountHistory_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTTOTAG
-- 
DROP TABLE IF EXISTS `AccountToTag`;

CREATE TABLE `accounttotag` (
  `accountId` mediumint(8) unsigned NOT NULL,
  `tagId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`accountId`,`tagId`),
  KEY `fk_AccountToTag_accountId` (`accountId`),
  KEY `fk_AccountToTag_tagId` (`tagId`),
  CONSTRAINT `fk_AccountToTag_accountId` FOREIGN KEY (`accountId`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_AccountToTag_tagId` FOREIGN KEY (`tagId`) REFERENCES `tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table ACCOUNTTOUSER
-- 
DROP TABLE IF EXISTS `AccountToUser`;

CREATE TABLE `accounttouser` (
  `accountId` mediumint(8) unsigned NOT NULL,
  `userId` smallint(5) unsigned NOT NULL,
  `isEdit` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`accountId`,`userId`),
  KEY `idx_AccountToUser_01` (`accountId`),
  KEY `fk_AccountToUser_userId` (`userId`),
  CONSTRAINT `fk_AccountToUser_accountId` FOREIGN KEY (`accountId`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_AccountToUser_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table AUTHTOKEN
-- 
DROP TABLE IF EXISTS `AuthToken`;

CREATE TABLE `authtoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` smallint(5) unsigned NOT NULL,
  `token` varbinary(255) NOT NULL,
  `actionId` smallint(5) unsigned NOT NULL,
  `createdBy` smallint(5) unsigned NOT NULL,
  `startDate` int(10) unsigned NOT NULL,
  `vault` varbinary(2000) DEFAULT NULL,
  `hash` varbinary(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_AuthToken_01` (`token`,`actionId`),
  KEY `idx_AuthToken_01` (`userId`,`actionId`,`token`),
  KEY `fk_AuthToken_actionId` (`actionId`),
  CONSTRAINT `fk_AuthToken_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table CONFIG
-- 
DROP TABLE IF EXISTS `Config`;

CREATE TABLE `config` (
  `parameter` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`parameter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table CUSTOMFIELDTYPE
-- 
DROP TABLE IF EXISTS `CustomFieldType`;

CREATE TABLE `customfieldtype` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_CustomFieldType_01` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table CUSTOMFIELDDEFINITION
-- 
DROP TABLE IF EXISTS `CustomFieldDefinition`;

CREATE TABLE `customfielddefinition` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `moduleId` smallint(5) unsigned NOT NULL,
  `required` tinyint(1) unsigned DEFAULT NULL,
  `help` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showInList` tinyint(1) unsigned DEFAULT NULL,
  `typeId` tinyint(3) unsigned NOT NULL,
  `isEncrypted` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_CustomFieldDefinition_typeId` (`typeId`),
  CONSTRAINT `fk_CustomFieldDefinition_typeId` FOREIGN KEY (`typeId`) REFERENCES `customfieldtype` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table CUSTOMFIELDDATA
-- 
DROP TABLE IF EXISTS `CustomFieldData`;

CREATE TABLE `customfielddata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `moduleId` smallint(5) unsigned NOT NULL,
  `itemId` int(10) unsigned NOT NULL,
  `definitionId` int(10) unsigned NOT NULL,
  `data` longblob,
  `key` varbinary(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_CustomFieldData_01` (`definitionId`),
  KEY `idx_CustomFieldData_02` (`itemId`,`moduleId`),
  KEY `idx_CustomFieldData_03` (`moduleId`),
  KEY `uk_CustomFieldData_01` (`moduleId`,`itemId`,`definitionId`),
  CONSTRAINT `fk_CustomFieldData_definitionId` FOREIGN KEY (`definitionId`) REFERENCES `customfielddefinition` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table EVENTLOG
-- 
DROP TABLE IF EXISTS `EventLog`;

CREATE TABLE `eventlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` int(10) unsigned NOT NULL,
  `login` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userId` smallint(5) unsigned DEFAULT NULL,
  `ipAddress` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `level` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table PUBLICLINK
-- 
DROP TABLE IF EXISTS `PublicLink`;

CREATE TABLE `publiclink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemId` int(10) unsigned NOT NULL,
  `hash` varbinary(100) NOT NULL,
  `data` mediumblob,
  `userId` smallint(5) unsigned NOT NULL,
  `typeId` int(10) unsigned NOT NULL,
  `notify` tinyint(1) DEFAULT '0',
  `dateAdd` int(10) unsigned NOT NULL,
  `dateExpire` int(10) unsigned NOT NULL,
  `dateUpdate` int(10) unsigned DEFAULT '0',
  `countViews` smallint(5) unsigned DEFAULT '0',
  `totalCountViews` mediumint(8) unsigned DEFAULT '0',
  `maxCountViews` smallint(5) unsigned NOT NULL DEFAULT '0',
  `useinfo` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_PublicLink_01` (`hash`),
  UNIQUE KEY `uk_PublicLink_02` (`itemId`),
  KEY `fk_PublicLink_userId` (`userId`),
  CONSTRAINT `fk_PublicLink_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table USERPASSRECOVER
-- 
DROP TABLE IF EXISTS `UserPassRecover`;

CREATE TABLE `userpassrecover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` smallint(5) unsigned NOT NULL,
  `hash` varbinary(255) NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_UserPassRecover_01` (`userId`,`date`),
  CONSTRAINT `fk_UserPassRecover_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table USERTOUSERGROUP
-- 
DROP TABLE IF EXISTS `UserToUserGroup`;

CREATE TABLE `usertousergroup` (
  `userId` smallint(5) unsigned NOT NULL,
  `userGroupId` smallint(5) unsigned NOT NULL,
  UNIQUE KEY `uk_UserToUserGroup_01` (`userId`,`userGroupId`),
  KEY `idx_UserToUserGroup_01` (`userId`),
  KEY `fk_UserToGroup_userGroupId` (`userGroupId`),
  CONSTRAINT `fk_UserToGroup_userGroupId` FOREIGN KEY (`userGroupId`) REFERENCES `usergroup` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_UserToGroup_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table PLUGIN
-- 
DROP TABLE IF EXISTS `Plugin`;

CREATE TABLE `plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `data` mediumblob,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `available` tinyint(1) DEFAULT '0',
  `versionLevel` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_Plugin_01` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 
-- Table NOTIFICATION
-- 
DROP TABLE IF EXISTS `Notification`;

CREATE TABLE `notification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `component` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `date` int(10) unsigned NOT NULL,
  `checked` tinyint(1) DEFAULT '0',
  `userId` smallint(5) unsigned DEFAULT NULL,
  `sticky` tinyint(1) DEFAULT '0',
  `onlyAdmin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_Notification_01` (`userId`,`checked`,`date`),
  KEY `idx_Notification_02` (`component`,`date`,`checked`,`userId`),
  KEY `fk_Notification_userId` (`userId`),
  CONSTRAINT `fk_Notification_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;







-- 
-- View ACCOUNT_DATA_V
-- 
DROP TABLE IF EXISTS `account_data_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sysPass`@`localhost` SQL SECURITY DEFINER VIEW `account_data_v` AS select `account`.`id` AS `id`,`account`.`name` AS `name`,`account`.`categoryId` AS `categoryId`,`account`.`userId` AS `userId`,`account`.`clientId` AS `clientId`,`account`.`userGroupId` AS `userGroupId`,`account`.`userEditId` AS `userEditId`,`account`.`login` AS `login`,`account`.`url` AS `url`,`account`.`notes` AS `notes`,`account`.`countView` AS `countView`,`account`.`countDecrypt` AS `countDecrypt`,`account`.`dateAdd` AS `dateAdd`,`account`.`dateEdit` AS `dateEdit`,conv(`account`.`otherUserEdit`,10,2) AS `otherUserEdit`,conv(`account`.`otherUserGroupEdit`,10,2) AS `otherUserGroupEdit`,conv(`account`.`isPrivate`,10,2) AS `isPrivate`,conv(`account`.`isPrivateGroup`,10,2) AS `isPrivateGroup`,`account`.`passDate` AS `passDate`,`account`.`passDateChange` AS `passDateChange`,`account`.`parentId` AS `parentId`,`category`.`name` AS `categoryName`,`client`.`name` AS `clientName`,`ug`.`name` AS `userGroupName`,`u1`.`name` AS `userName`,`u1`.`login` AS `userLogin`,`u2`.`name` AS `userEditName`,`u2`.`login` AS `userEditLogin`,`publiclink`.`hash` AS `publicLinkHash` from ((((((`account` left join `category` on((`account`.`categoryId` = `category`.`id`))) join `usergroup` `ug` on((`account`.`userGroupId` = `ug`.`id`))) join `user` `u1` on((`account`.`userId` = `u1`.`id`))) join `user` `u2` on((`account`.`userEditId` = `u2`.`id`))) left join `client` on((`account`.`clientId` = `client`.`id`))) left join `publiclink` on((`account`.`id` = `publiclink`.`itemId`)));

-- 
-- View ACCOUNT_SEARCH_V
-- 
DROP TABLE IF EXISTS `account_search_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sysPass`@`localhost` SQL SECURITY DEFINER VIEW `account_search_v` AS select `account`.`id` AS `id`,`account`.`clientId` AS `clientId`,`account`.`categoryId` AS `categoryId`,`account`.`name` AS `name`,`account`.`login` AS `login`,`account`.`url` AS `url`,`account`.`notes` AS `notes`,`account`.`userId` AS `userId`,`account`.`userGroupId` AS `userGroupId`,`account`.`otherUserEdit` AS `otherUserEdit`,`account`.`otherUserGroupEdit` AS `otherUserGroupEdit`,`account`.`isPrivate` AS `isPrivate`,`account`.`isPrivateGroup` AS `isPrivateGroup`,`account`.`passDate` AS `passDate`,`account`.`passDateChange` AS `passDateChange`,`account`.`parentId` AS `parentId`,`account`.`countView` AS `countView`,`account`.`dateEdit` AS `dateEdit`,`user`.`name` AS `userName`,`user`.`login` AS `userLogin`,`usergroup`.`name` AS `userGroupName`,`category`.`name` AS `categoryName`,`client`.`name` AS `clientName`,(select count(0) from `accountfile` where (`accountfile`.`accountId` = `account`.`id`)) AS `num_files`,`publiclink`.`hash` AS `publicLinkHash`,`publiclink`.`dateExpire` AS `publicLinkDateExpire`,`publiclink`.`totalCountViews` AS `publicLinkTotalCountViews` from (((((`account` join `category` on((`account`.`categoryId` = `category`.`id`))) join `client` on((`client`.`id` = `account`.`clientId`))) join `user` on((`account`.`userId` = `user`.`id`))) join `usergroup` on((`account`.`userGroupId` = `usergroup`.`id`))) left join `publiclink` on((`account`.`id` = `publiclink`.`itemId`)));

INSERT INTO `Client` VALUES(1,'raul.sigoli@anpad.org.br','fe09c2460e4c74bca579f844014a2f0f','raul.sigoli@anpad.org.br',1);
INSERT INTO `Client` VALUES(2,'raul@anpad.org.br','cbb4ae938f42940f55a8117d20fa5006','raul@anpad.org.br',1);
INSERT INTO `Category` VALUES(1,'raul.sigoli@anpad.org.br','raul.sigoli@anpad.org.br','fe09c2460e4c74bca579f844014a2f0f');
INSERT INTO `Category` VALUES(2,'raul@anpad.org.br','raul@anpad.org.br','cbb4ae938f42940f55a8117d20fa5006');
INSERT INTO `Tag` VALUES(1,'raul.sigoli@anpad.org.br','fe09c2460e4c74bca579f844014a2f0f');
INSERT INTO `Tag` VALUES(2,'raul@anpad.org.br','cbb4ae938f42940f55a8117d20fa5006');
INSERT INTO `UserGroup` VALUES(1,'Admins','sysPass Admins');
INSERT INTO `UserGroup` VALUES(2,'raul.sigoli@anpad.org.br','');
INSERT INTO `UserGroup` VALUES(3,'raul@anpad.org.br','raul@anpad.org.br');
INSERT INTO `UserProfile` VALUES(1,'Admin','O:24:\"SP\\DataModel\\ProfileData\":30:{s:10:\"\0*\0accView\";b:0;s:14:\"\0*\0accViewPass\";b:0;s:17:\"\0*\0accViewHistory\";b:0;s:10:\"\0*\0accEdit\";b:0;s:14:\"\0*\0accEditPass\";b:0;s:9:\"\0*\0accAdd\";b:0;s:12:\"\0*\0accDelete\";b:0;s:11:\"\0*\0accFiles\";b:0;s:13:\"\0*\0accPrivate\";b:0;s:18:\"\0*\0accPrivateGroup\";b:0;s:16:\"\0*\0accPermission\";b:0;s:17:\"\0*\0accPublicLinks\";b:0;s:18:\"\0*\0accGlobalSearch\";b:0;s:16:\"\0*\0configGeneral\";b:0;s:19:\"\0*\0configEncryption\";b:0;s:15:\"\0*\0configBackup\";b:0;s:15:\"\0*\0configImport\";b:0;s:11:\"\0*\0mgmUsers\";b:0;s:12:\"\0*\0mgmGroups\";b:0;s:14:\"\0*\0mgmProfiles\";b:0;s:16:\"\0*\0mgmCategories\";b:0;s:15:\"\0*\0mgmCustomers\";b:0;s:15:\"\0*\0mgmApiTokens\";b:0;s:17:\"\0*\0mgmPublicLinks\";b:0;s:14:\"\0*\0mgmAccounts\";b:0;s:10:\"\0*\0mgmTags\";b:0;s:11:\"\0*\0mgmFiles\";b:0;s:17:\"\0*\0mgmItemsPreset\";b:0;s:6:\"\0*\0evl\";b:0;s:18:\"\0*\0mgmCustomFields\";b:0;}');
INSERT INTO `UserProfile` VALUES(2,'Anpad','O:24:\"SP\\DataModel\\ProfileData\":30:{s:10:\"\0*\0accView\";b:1;s:14:\"\0*\0accViewPass\";b:1;s:17:\"\0*\0accViewHistory\";b:1;s:10:\"\0*\0accEdit\";b:1;s:14:\"\0*\0accEditPass\";b:1;s:9:\"\0*\0accAdd\";b:1;s:12:\"\0*\0accDelete\";b:0;s:11:\"\0*\0accFiles\";b:1;s:13:\"\0*\0accPrivate\";b:0;s:18:\"\0*\0accPrivateGroup\";b:0;s:16:\"\0*\0accPermission\";b:0;s:17:\"\0*\0accPublicLinks\";b:0;s:18:\"\0*\0accGlobalSearch\";b:0;s:16:\"\0*\0configGeneral\";b:0;s:19:\"\0*\0configEncryption\";b:0;s:15:\"\0*\0configBackup\";b:0;s:15:\"\0*\0configImport\";b:0;s:11:\"\0*\0mgmUsers\";b:0;s:12:\"\0*\0mgmGroups\";b:0;s:14:\"\0*\0mgmProfiles\";b:0;s:16:\"\0*\0mgmCategories\";b:0;s:15:\"\0*\0mgmCustomers\";b:0;s:15:\"\0*\0mgmApiTokens\";b:0;s:17:\"\0*\0mgmPublicLinks\";b:0;s:14:\"\0*\0mgmAccounts\";b:0;s:10:\"\0*\0mgmTags\";b:0;s:11:\"\0*\0mgmFiles\";b:0;s:17:\"\0*\0mgmItemsPreset\";b:0;s:6:\"\0*\0evl\";b:0;s:18:\"\0*\0mgmCustomFields\";b:0;}');
INSERT INTO `User` VALUES(1,'sysPass Admin',1,'admin','','$2y$10$SOgeiqFdpp1jifg3D./X3.3mW.QOEe3E19d1xbB.cEi6K4XgGVOTa','def50200cd6660e0b0b9284cd69c6e8cbc0e02eee3f8fd4541d2b5f687b44b4a637f95007aa90a98a61b519ff88d88e628ae712a0a3bae778f7b7a54226e4e9b36a0f78c2ac3d431be70abcbae62f671d0f029b5123e55ae2acfd58c834ebb','def10000def50200302a8181d7bc90906a37c798286ba88b77e9e4be28e9ef141283c0bfc60534d46f01734070a836d8b78634fe8e57a9502147d3e58412c197efe32510bc4deed35a2e4911323d18633a96637ac576c6d774415f49c12eef8f6e55e308dd19d7c95c7897c38bcf811f41b1145d4d189cfc5f7535fe59a9540bee0f7daca99c57211925a24699dec493ba99a3ba707c0600c31970cb2b164840305484a623f06b411740199c0dd07518f6d6608e6ea5a84d71484f18975c8a439b42b68894de389a0705e2294e12cdf97c35af01dabd5057d1488f97c8677da6a6c384af6c4f5f069483e71a18d820baacc6dfd5c029b4b98b99ab95b65e52d3','','',20,1,'2020-10-28 11:38:20','',1603891529,1,0,0,0,'',0,0,0,'O:32:\"SP\\DataModel\\UserPreferencesData\":11:{s:7:\"user_id\";i:1;s:4:\"lang\";s:5:\"pt_BR\";s:5:\"theme\";s:13:\"material-blue\";s:14:\"resultsPerPage\";i:0;s:11:\"accountLink\";b:0;s:9:\"sortViews\";b:0;s:9:\"topNavbar\";b:0;s:15:\"optionalActions\";b:1;s:14:\"resultsAsCards\";b:1;s:18:\"checkNotifications\";b:1;s:24:\"showAccountSearchFilters\";b:0;}');
INSERT INTO `User` VALUES(2,'Raul Henrique Silva Sigoli',2,'raul.sigoli@anpad.org.br','','$2y$10$64suugw1G3.H.gf4MZ3zEuFZw2PBB/qQtPHT5PMFnFmgCOZAfkCE6','def5020071064f7a5a8ac3158c9d06d6151c7d4047a70888a2c79ed074ce26396671e2def27079ebd37e9575450ed362da855fd41d92a074f2919e94f8fb628779e0863bdf6e66dec60d1a50ede8a1efd0b5f3826ee736a9299b2c5d7dbad3','def10000def50200991c779f8438047df59911bbdbc1575955ec8b6d70e7d1c9d97ee9dbd63a82955692c8933c1caa7bae23c6e21989e875de3561737120f0d7716d41861eff86abf9e51fffcb70f1cc381146381d92b2abd06f3e8835dbb0cf3ee99551bdc08dec09940eae5230a06f341e396ede52f0e51f3361cc953ab4394812e30f90f6ae8aa1f222f516daf071c3e5d445f12357a18fcd06805c1bf6efeec73f38684ee4df175f0a435911490f7d557e34804f0e981cc7e5fe47b7b7aeef7745b5198973f0553adf57e0add3006169a541b4f00690b52d4ad01f4fe93dc041cd223bdd09c135ef9f5814bf5dd1ffc55c5053eac1bfaf8a0ef9e86b75c5','raul.sigoli@anpad.org.br','',14,2,'2020-10-28 11:20:15','2020-10-28 10:31:47',1603892099,0,0,0,0,'',0,0,0,'');
INSERT INTO `User` VALUES(3,'raul',3,'raul@anpad.org.br','','$2y$10$PfL6NbLULmyxMmimPvET2uCoWEzBgMWaSVNVw5kNCdZZQ6TwZfFyW','def502005ea31241e0ac2f5ed0edc509c2bcc253e4d81a09bd7aa5fd669820db41b9d24856164aa7962d45f81336c77381d18caa6daf8405c1b4c2f8437e93d5793111c4faa33327b9fd486481edac3cc1de0df14604c3f7b9199a6d32b648','def10000def502005941b70e685227833cef2c128ef45ef84d1d33f952ae6b6044a727da40632d585d5415041ad18d04da7aff93d5fa5e96356088da6a86a84661f3b32afff66962450a47f0fc96195db532f69c0e76d1c7b4a109c999373cbfd1c0ecaec1f3115ccb621c7a04eb8fd99855c3718c5a01dbd5ca93d7e990500195b4d46b5f5ed780a3a877fe487e4e7fcd50037a43ddb3c56e0726a5ed70eadf779bd52651593ae9190d3ce430cb03b66992d7650a36491bec3a631153884ad28577370d6b8cee15861cd37fb69760d25edbb57235ad6cb6dee07df175c964ac9190d64f9f9a77f128d0108bcb3c930a8a3f8199533ea1bbad200ecd10b0a336','raul@anpad.org.br','',2,2,'2020-10-28 11:07:34','',1603894053,0,0,0,0,'',0,0,0,'');
INSERT INTO `Account` VALUES(1,2,2,1,1,'Raul Henrique Silva Sigoli',1,'raul.sigoli@anpad.org.br','','def502008d4f9c63ddc91ebc6f5ecd2e9b57964a92f59849b823c21ad974e9616a66b6fbb8ca48a29d62e001e26f609bb74f1a500f61e1950c34d8ea46fbf30bd117915230ea8f52e7c8b710ca32879cdb1682fef74086c9fe91834133c1df','def10000def502009375669dc723336349784b238a6bf9566f70904c3e4067ec1e2132f2e1c7ec585d78c48fe7184d5a1d0d0c3e604e6de6f76754600c106e94a14e1d0487d58fc6d9961ced972f28afb1187016036d87fcc1a89504c50c9c2ec008a5898a5671b61274719b3dec073b03a77da575ac9c58be7e942a18245a94d394a36ada3e811a41130b73a3b8799efb6b553780b26fe5baa6f0886919aad7108bad395b67116d8be1d1aa2bab9b3044fff46213d84b90902d841f17df586f84f6d06fbda4fadc92f268d53077760ebb47be3d4072646c74d7eb4688dcf1ea76f5236b08442cde40a8b18c247550d4b622165f887ad7465f0b8a0aa3f48c12','',10,0,'2020-10-28 10:34:03','2020-10-28 11:19:59',0,0,0,0,'','','');
INSERT INTO `Account` VALUES(2,3,3,3,2,'raul@anpad.org.br',2,'raul@anpad.org.br','','def502009d14a64d22b62fded7bb4db352040b6086cc7b6885d32311558d9c41de1e69f0e2d8140c470a1762300d614ff48f9eb2d3bdaa0dd9c8960915506b8d37696a9af50c41c3fbfc0aa0cf19ea04298c53276c12bee5b63420af2990cc','def10000def5020063733d72b7c951da751d27d3839497c6f51224938c1b602e3b2f8243237d7606cd6dfc23689f73641d066728e2d535e85c3f0626529a224a73916c01300f4558c34e0f27d5b7e72f80148ea7b5eb3785863ba6fdef35c55f6c2cec818c856f3d8095e11577fc78d6de270b01010943976de9654c78b9c489f93b7aa023bc3793a5543576a539ced94a36dfddf436e1f962433bafc6f33da3955ceb852c6698b8f8d1837d04473e7a4464e19f85e49b4c1d3b200c84c6dfabbc5699fda8727029fb2c7421a6ba82897ac82e291d7eca86f714d18d47739d0ac545bb06c9298ef7ef5cf21f62c9b54364818e5767cff0a9d0d36c6a72a4cb9a','',3,0,'2020-10-28 11:06:15','',0,0,0,0,1603893975,'',0);
INSERT INTO `AccountToUserGroup` VALUES(1,2,1);
INSERT INTO `AccountToUserGroup` VALUES(2,3,1);
INSERT INTO `AccountToTag` VALUES(1,1);
INSERT INTO `AccountToTag` VALUES(2,2);
INSERT INTO `AccountToUser` VALUES(1,2,1);
INSERT INTO `AccountToUser` VALUES(2,3,1);
INSERT INTO `Config` VALUES('config_backup','789c95585b8f9b3818ed6f89b44f5552c00442e6697a5f75dace36d36a575aa93260123706b3d86498a9fadfd79f813421189897c9249c83edf3ddfd79ed58ebd9e6f6df573c4be8b6f9788d259ead03b4fe29d6c859cf9ef5019e95f9b6c031f9401e665762ad5e031fc837c163be2fefe99ebec970c8483cbba26b0b08688cf0b5604f5a40e15f62414e39ee284790e249845b2cc4292118237cc22911398ecef6b532b1588cf3d724c12593ef0a5ee62724d79a40ba2d7842d9340df282570f93ada2d11b521cce05b307f1b7bc90f0ea95b5b2c6d15d638cbcbb6309a3a67919329aedc5475c7da3e45ec086d0a0479d30ee684a80e059d6244a574fa3fa388a7899c957f007d0b633287f03bf516bccaec2b53df8ee6847a2fdd73cc69208400fef44a3332e69748236467fa4ff7d8fc5ae75cad88d88e3c5d80a431f113b2176e8256869bb2b9f047612b85eb02404bb80778c568ac3f75c48c0a890623cc26cd77c4746c78fc30d8ff6449eb8c1d002108a805110f120c07fec314aeb64b6b79edd7eb06ede79de3fd5fa0f7ff5d7df728cdbba337045fe7d9904816fa32474426b7cdd267010b23c809a931f09cbedd16ae69c4a52de754de3f29041c43563fc9ec46f2a392dca4e491f75d060f08e9ff5628e8a659ce78c4658529ebda8e638a4f7bcd0bb016776dc73008f249173210b8253c0388d60a79843162f708a1f79b62021e7fb36b09503d1146fc98b30cde137178cb0ea6e207ca4fae9129e067d4f1d1df8f0d8ef3e8ec0fde9daafbd49924abe88c441a7ba9ec552d11e35504f7dfbf2183c275995b28417299662ce93444563cca33225995c005be53c159f8266db942dda275a3dad6f70f9ce54cc139e491efe20518dd4425be748a232d7f3460a9d838eea6d69a27f6c24d587dcc994e91fb5a6a83d3a66248b71a19f2c7bacf9031ff01c17d18e1e7436b5b5aa56bbd28f9c6cf5cf7e132e675cc133fd109445cb1e1750dfc982664262c648f1bc6ab6085abb7e8fd65850a1153f0a9c1744a84f8dd1de069abade24ae50641c8b1d215a64c76eda820954104f73ce74cf332d8603badb9df3e6b1b689e39a6d9eab082c724e6bef70c01c3e7aaac79d0aa2fced421faf271cab79818b79c453408b3ad1387ecf210a591f62d563ed6a5e479613340e566b220edbd6aec8ea8d4859bb1fb21bcfd28e99334cf58691d393844086031594d799b62f4d81bf1f17767b3cbb119d5411a941a0b7d7e3a5c37a9f389192fbe84cc8eb91afdd8edff44817dbe18f9431bca8cadf5b5ff5bca7097a143405e65c4ffff1cc94bfa6e6fe0d7dac1b26db7507db0e4d3ad6a4b19666cb7888d986401239a28d0d629b0c8ee5c5dc4340f33c796cd0609ac593c78696d06d56974384dbbe66d858da81d129ed8e712a01f0752c8e3dc0a02c770f3999d48f03b83bae983b48405f0e126638df76bdc4bc11853da87812d07da8e6e3d750cb9e62caae4bb92353472020749b28a380007e5bf0f4f48c83e0ae8b0c839bfe50a777d7a80740bf90ff4a22e4f4c904481b129505950f932c5413ba061ddc7fd7bbbde1134434a7b559276ea7f58209f1a3e099543e90c1883e362be5ca48d08d6d30d3fdbfa75e1f201206c8f603cbf77d68ee430745ae6b11d77196aeb3b2021cc4aee70451622fd1320cc2c4f15708ad501c0f1f5e255f35d38b6bf10a17f1efd9cc8817d020f20c66565ed605c41af6524125b9c1d07088b5ca49b9fcfef2cb70ac03e36e47ea490a0ab42a67a4a098cd435692e1e456cf8edf4821741fa1f8ca88c876168e6521cbafc722b36155811ae39ae724f52754697eec054637e9bbc232ee14c06f29931353787db1b425e5f98d975147c0d7a5b0c31899dad5bf4dfb6da155e0ba3e7445ae91d4de69fc092dd8e48ba21047fb32ffbe6b6e08460f4faa5c25b30bbc31047752e6a77d833528951af4cf0b883598306bf817352dcb8b131b7754939e50d26a429bc3977a98325fef35573f501feeb8b6c5f8bc5fdb7b839b1d41e717a7341b4e37248b8a875c6eea2c72146bec0aeb6dc998aefed7114ca8c7cd19db45ac8aae6ab968d4a9ebae317a8f0c55aff90ddfd2acdb128c535ff314d70a8cde280bc1cf2f611b0f30b655bf09c70bd8facac21c5c8d786faa9c16a4ebcec685ce58eddda46d216f6559c3b5413774eca20b30e24fa6017d11ffe9ead7ff9b19f2bb');
INSERT INTO `Config` VALUES('config_backup_date',1603895926);
INSERT INTO `Config` VALUES('lastupdatempass',1603891528);
INSERT INTO `Config` VALUES('masterPwd','$2y$10$xAb3bnOaNsdaFHHd0Z3d1./cuvm24u1WIjv.5pHwPLsu0oP4yxHsu');
INSERT INTO `Config` VALUES('version',312.20030701);
INSERT INTO `CustomFieldType` VALUES(1,'text','Text');
INSERT INTO `CustomFieldType` VALUES(2,'password','Password');
INSERT INTO `CustomFieldType` VALUES(3,'date','Date');
INSERT INTO `CustomFieldType` VALUES(4,'number','Number');
INSERT INTO `CustomFieldType` VALUES(5,'email','Email');
INSERT INTO `CustomFieldType` VALUES(6,'telephone','Phone');
INSERT INTO `CustomFieldType` VALUES(7,'url','URL');
INSERT INTO `CustomFieldType` VALUES(8,'color','Color');
INSERT INTO `CustomFieldType` VALUES(9,'wiki','Wiki');
INSERT INTO `CustomFieldType` VALUES(10,'textarea','Text Area');
INSERT INTO `CustomFieldDefinition` VALUES(1,'Text',1,0,'Text',0,1,1);
INSERT INTO `CustomFieldDefinition` VALUES(3,'Text',1,0,'Text',0,1,1);
INSERT INTO `CustomFieldDefinition` VALUES(5,'Senha',1,0,'Senha',0,2,1);
INSERT INTO `CustomFieldDefinition` VALUES(6,'Senha',1,0,'Senha',0,2,1);
INSERT INTO `CustomFieldDefinition` VALUES(7,'Coloque suas informações',1,0,'Coloque suas informações',0,10,1);
INSERT INTO `CustomFieldDefinition` VALUES(8,'Coloque suas informações',1,0,'Coloque suas informações',0,10,1);
INSERT INTO `CustomFieldDefinition` VALUES(9,'Senha',1,0,'Senha',0,2,1);
INSERT INTO `CustomFieldDefinition` VALUES(10,'Senha',1,0,'Senha',0,2,1);
INSERT INTO `CustomFieldDefinition` VALUES(11,'Coloque suas informações',1,0,'Coloque suas informações',0,10,1);
INSERT INTO `CustomFieldDefinition` VALUES(12,'Coloque suas informações',1,0,'Coloque suas informações',0,10,1);
INSERT INTO `CustomFieldDefinition` VALUES(13,'Text',1,0,'Text',0,1,1);
INSERT INTO `CustomFieldDefinition` VALUES(14,'Text',1,0,'Text',0,1,1);
INSERT INTO `CustomFieldData` VALUES(1,1,1,5,'def50200c3f06b0fde1a052c39c8847448daaf5aaf977557fe8732445aa2ae8ed9043c8bb0fffa0584e148619ad40c9e5f1e6135f9045a23f33e894ae8a851226a0f7e613ef7cf5e1eb82f533a49eba17c634994a1e047aeb1e3032b207e50','def10000def5020070ae3169956c672d8a2d08debfd3052d60f94126610c65b6fa1c49b60aac6ccbb1b58fef2a26ef9f881527cd1cbd703898b4538914a93cb05e6d6f352b9ce7547a2ca920c4bf368aacb4db85a1b4f8d28d724e647b8d39f12c0638f378617777895a703e534d68b7749f38dfff6a44d23fc8b3342b58d95c2469159048cb63fe8f931990449049214ad89b7f064cbbd93a5d0922ba3973bb37d9825e85de6362c3ff90ff644a29b0ceb930449ba91bbffa259583a0d428c302f3c887c2a1f09e6def76c3c5a1ed6b05d2059564e00f6b3e6853fa7459e784252be3a378429e6c9a02dd1fc72c20e5cef70fbe1a5a912f832a06f23c5dd542');
INSERT INTO `EventLog` VALUES(1,1603893171,'admin',1,'::1','save.config.account','','INFO');
INSERT INTO `EventLog` VALUES(2,1603894472,'admin',1,'::1','save.config.account','','INFO');
INSERT INTO `EventLog` VALUES(3,1603894514,'admin',1,'::1','show.authToken.create','','INFO');
INSERT INTO `EventLog` VALUES(4,1603895926,'admin',1,'::1','save.config.general','','INFO');
INSERT INTO `UserToUserGroup` VALUES(2,2);
INSERT INTO `Plugin` VALUES(1,'Authenticator','',0,1,'');
-- 
SET AUTOCOMMIT = 1;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
-- 
-- sysPass DB dump generated on 1603896115 (END)
-- 
-- Please, do not alter this file, it could break your DB
-- 

